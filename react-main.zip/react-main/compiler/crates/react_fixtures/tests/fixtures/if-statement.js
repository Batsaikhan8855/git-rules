function foo(a, b, c, d) {
  if (a) {
    return b;
  } else {
    c;
  }
  d;
}
