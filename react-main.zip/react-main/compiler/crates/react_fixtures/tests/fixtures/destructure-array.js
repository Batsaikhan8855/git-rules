function Component(a, b) {
  const [c, , ...d] = a;
  const [[[e]], ...[f]] = b;
  return [c, d, e, f];
}
