function Component(props) {
  let x = [];
  let foo = () => {
    x = {};
  };
  foo();
  return x;
}
