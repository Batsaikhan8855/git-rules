/* eslint-disable react-hooks/rules-of-hooks */
function lowercasecomponent() {
  "use forget";
  const x = [];
  return <div>{x}</div>;
}
/* eslint-enable react-hooks/rules-of-hooks */
