function Component(props) {
  const ref = useRef(null);
  return <Foo ref={ref} />;
}
