function Component(props) {
  const x = useState;
  const state = x(null);
  return state[0];
}
