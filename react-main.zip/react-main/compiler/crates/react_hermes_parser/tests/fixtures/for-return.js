function Component(props) {
  for (let i = 0; i < props.count; i++) {
    return;
  }
}
