function Component(props) {
  return foo?.(props);
}
