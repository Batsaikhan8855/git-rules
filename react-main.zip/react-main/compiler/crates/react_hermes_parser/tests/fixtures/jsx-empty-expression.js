export function Component(props) {
  return (
    <div>
      {}
      {props.a}
    </div>
  );
}
