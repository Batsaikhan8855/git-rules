function t(props) {
  let [, setstate] = useState();
  setstate(1);
  return props.foo;
}
