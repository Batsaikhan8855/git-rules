function useFoo(props) {
  [x] = props;
  return { x };
}
