function foo(a, b) {
  let x = [];
  let y = [];
  y.push(b);
  x.push(a);
}
